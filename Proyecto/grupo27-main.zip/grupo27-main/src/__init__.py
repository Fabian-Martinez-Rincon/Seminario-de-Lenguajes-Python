'''Makes src folder behave like a module.'''
