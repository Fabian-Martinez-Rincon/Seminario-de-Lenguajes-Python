# Apartados a realizar del trabajo


## Segunda entrega

[X] Sistema de ayudas (hecho en primer entrega)

[X] Rehacer el procesamiento de los datsets con Pandas y generar el Jupyter Notebook correspondiente

[X] Pantalla de puntajes, con dos columnas:

- Primera columna mejores 20 puntajes para cada dificultad

- Segunda columna mejores 20 puntajes promedios para cada dificultad

> Si se abandona la partida no se guardan los puntos

[X] Registro de jugadas y partidas

[ ] Análisis de datos y estadísticas

[ ] Documentar el código usando docstrings en las funciones y clases